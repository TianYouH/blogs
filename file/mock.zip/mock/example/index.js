const getExampleData = require('./getExampleData');
module.exports = [
  {
    url: '/example',
    type: 'get',
    response: (req) => getExampleData(req)
  }
];
