/* eslint-disable no-unused-vars */
const Mock = require('mockjs');
module.exports = (req) => {
  // req为node的express框架提供的请求对象,其他高级用法参考https://www.expressjs.com.cn/4x/api.html#req
  // get请求获取参数方式
  const { pageSize } = req.query;
  // post请求获取参数方式
  // const { pageSize } = req.body;
  return {
    result: {
      h: '黄金',
      // 生成一个100-10000随机Number类型的整数
      total: '@integer(100,10000)',
      // 生成一个包含pageSize条数据的数组
      [`list|${pageSize}`]: [
        {
          // 生成一个String类型的随机id
          id: '@id',
          // 生成一个随机2-10长度的中文字符串
          key0: '@cword(2,10)',
          // 生成一个随机的中文姓名
          key1: '@cname',
          // 生成一个和key1字段一模一样的值
          key2: '@key1',
          // 生成一个和id字段一模一样的值,所以如果要生成一个随机的id,应该使用key4的方式
          key3: '@id',
          // 生成一个String类型的随机id,
          key4: (_) => Mock.mock('@id'),
          // 从数组的所有元素中随机选取一个
          'key5|1': ['0', '1', '2'],
          // key6要生成的值依赖于key5的情况下,可以使用函数的方式来实现
          key6: function () {
            if (this.key5 === '0') {
              return '索引0';
            } else if (this.key5 === '1') {
              return '索引1';
            } else if (this.key5 === '2') {
              return '索引2';
            }
            return '索引null';
          },
          // 生成yyyy-MM-dd A HH:mm:ss格式的日期时间
          key7: '@datetime',
          // 生成一个1-100的随机整数,结果为Number类型
          key8: '@integer(1,100)',
          // 生成一个1-100的随机数,结果为String类型
          key9: (_) => String(Mock.mock('@integer(1,100)')),
          // 生成一个1-100的随机浮点数,且小数部分的位数为1-2位,结果为Number类型
          key10: '@float(1,100,1,2)',
          // 生成一个1-100的随机浮点数,且小数部分的位数为1-2位,结果为String类型
          key11: (_) => String(Mock.mock('@float(1,100,1,2)')),
          // 生成一个色值,如#f2ea79
          key12: '@color',
          // 生成一个url
          key13: '@url',
          // 生成一个域名
          key14: '@domain',
          // 生成一个协议
          key15: '@protocol',
          // 生成一个邮箱地址
          key16: '@email',
          // 生成一个ip地址
          key17: '@ip',
          // 生成一个区域
          key18: '@region',
          // 生成一个省份
          key19: '@province',
          // 生成一个城市
          key20: '@city',
          // 生成一个县
          key21: '@county',
          // 生成一个boolean值
          key22: '@boolean',
          // 生成一个符合正则表达式的值,此处生成了一个合法的车牌号码
          key23:
            /^(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z](([0-9]{5}[DF])|([DF]([A-HJ-NP-Z0-9])[0-9]{4})))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9学警港澳使领]))$/,
          // 根据函数自定义生成值
          key24: function () {
            // 自定义任何想要的返回值
            let anything;
            return anything;
          }
        }
      ]
    },
    status: true,
    statusCode: '200',
    message: '操作成功'
  };
};
