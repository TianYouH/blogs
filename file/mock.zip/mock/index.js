const Mock = require('mockjs');

// mock文件夹下的所有mock数据需要在此处引入
const example = require('./example');
const mocks = [...example];

// for mock server
const responseFake = (url, type, respond) => ({
  url: new RegExp(`${url}$`),
  type: type || 'get',
  response(req, res) {
    const response = respond instanceof Function ? respond(req, res) : respond;
    const contentType = res.get('Content-Type');
    if (contentType === undefined) {
      res.json(Mock.mock(response));
    } else {
      res.end();
    }
  }
});

module.exports = mocks.map((route) =>
  responseFake(route.url, route.type, route.response)
);
